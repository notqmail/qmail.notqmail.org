/*
  msntauth

  Modified to act as a Squid authenticator module.
  Removed all Pike stuff.
  Returns OK for a successful authentication, or ERR upon error.

  Antonino Iannella, Camtech SA Pty Ltd
  Mon Apr 10 22:24:26 CST 2000

  Uses code from -
    Andrew Tridgell 1997
    Richard Sharpe 1996
    Bill Welliver 1999

  Released under GNU Public License

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <stdio.h>
#include <signal.h>
#include <sys/time.h>
#include "sitedef.h"
#include <errno.h>
extern int errno;
extern char *crypt();

extern void Checkforchange();       /* For signal() to find the function */

/* Main program for simple authentication.
   Reads the denied user file. Sets alarm timer.
   Scans and checks for Squid input, and attempts to validate the user.
*/

extern char **environ;

int error_txtbsy =
#ifdef ETXTBSY
ETXTBSY;
#else
-4;
#endif

#include "prot.h"
#include <pwd.h>
static struct passwd *pw;
static char *stored;

#include "hasspnam.h"
#ifdef HASGETSPNAM
#include <shadow.h>
static struct spwd *spw;
#endif

#include "hasuserpw.h"
#ifdef HASUSERPW
#include <userpw.h>
static struct userpw *upw;
#endif

void doit(char* login)
{
  pw = getpwnam(login);
  if (pw)
	{
    stored = pw->pw_passwd;
	}
  else {
    if (errno == error_txtbsy) _exit(111);
    _exit(1);
  }

#ifdef HASUSERPW
  upw = getuserpw(login);
  if (upw)
    stored = upw->upw_passwd;
  else
    if (errno == error_txtbsy) _exit(111);
#endif

#ifdef HASGETSPNAM
  spw = getspnam(login);
  if (spw)
    stored = spw->sp_pwdp;
  else
    if (errno == error_txtbsy) _exit(111);
#endif
}

char *str1e2(name,value) char *name; char *value;
{
  char *nv;
  nv = malloc(strlen(name) + strlen(value) + 2);
  if (!nv) _exit(111);
  strcpy(nv,name);
  strcat(nv,"=");
  strcat(nv,value);
  return nv;
}

//From checkpassword
#include "hasshsgr.h"
#include "prot.h"

int prot_gid(gid) int gid;
{
#ifdef HASSHORTSETGROUPS
  short x[2];
  x[0] = gid; x[1] = 73; /* catch errors */
  if (setgroups(1,x) == -1) return -1;
#else
  if (setgroups(1,&gid) == -1) return -1;
#endif
  return setgid(gid); /* _should_ be redundant, but on some systems it isn't */
}

int prot_uid(uid) int uid;
{
  return setuid(uid);
}

int main(int argc,char* argv[])
{
char username[256];
char wstr[256];
struct itimerval TimeOut;

char *login;
char *password;
char *encrypted;
int r;
int i;
char **newenv;
int numenv;
char up[513];
int uplen;


// Read denied user file. If it fails there is a serious problem.
// Check syslog messages. Deny all users while in this state.
// The process should then be killed.

if(Read_denyusers()==1)
	{
	while(1)
		{
		fgets(wstr, 255, stdin);
		puts("ERR");
		fflush(stdout);
		}
	}

//An alarm timer is used to check the denied user file for changes every minute. Reload the file if it has changed.
TimeOut.it_interval.tv_sec = 60;
TimeOut.it_interval.tv_usec = 0;
TimeOut.it_value.tv_sec = 60;
TimeOut.it_value.tv_usec = 0;
setitimer(ITIMER_REAL, &TimeOut, 0);
signal(SIGALRM, Checkforchange);
signal(SIGHUP, Checkforchange);

//Getting parameters
if(!argv[1])
	_exit(2);

uplen=0;
for(;;)
	{
	do
		r=read(3,up + uplen,sizeof(up) - uplen);
	while((r==-1)&&(errno==EINTR));
	if (r==-1)
		_exit(111);
	if(!r)
		break;
	uplen+=r;
	if(uplen>=sizeof(up))
		_exit(1);
	}

close(3);

i=0;
login=up+i;
while(up[i++])
	if(i==uplen)
		_exit(2);
password=up+i;
if(i==uplen)
	_exit(2);
while(up[i++])
	if(i==uplen)
		_exit(2);

//Checking password
if(Check_user(login)==1)
	_exit(2);
else
	{
	if(Valid_User(login,password,PRIMARY_DC,BACKUP_DC,NTDOMAIN)==0)
		{
		doit(login);

		for(i=0;i<sizeof(up);++i)
			up[i]=0;

		if(prot_gid((int)pw->pw_gid)==-1)
			_exit(1);
		if(prot_uid((int)pw->pw_uid)==-1)
			_exit(1);
		if(chdir(pw->pw_dir)==-1)
			_exit(111);

		numenv=0;
		while(environ[numenv])
			++numenv;
		newenv=(char**)malloc((numenv+4)*sizeof(char*));
		if(!newenv)
			_exit(111);
		for(i=0;i<numenv;++i)
			newenv[i]=environ[i];

		newenv[numenv++]=str1e2("USER",pw->pw_name);
		newenv[numenv++]=str1e2("HOME",pw->pw_dir);
		newenv[numenv++]=str1e2("SHELL",pw->pw_shell);
		newenv[numenv]=0;
		environ=newenv;
		execvp(argv[1],argv + 1);
		_exit(111);
		}
	else//bad password
		_exit(2);
	}

return(0);
}
