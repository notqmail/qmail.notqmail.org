appath PATH /var/qmail/bin

# make ~/Mailbox(Maildir) the inbox for users and 
# /var/qmail/alias/Mailbox(Maildir) for root 
if [ `id -u` = "0" ]; then
    if grep -q './Mailbox' /var/service/qmail/defaultdelivery/rc; then
	MAIL="/var/qmail/alias/Mailbox"
    elif grep -q './Maildir/' /var/service/qmail/defaultdelivery/rc; then
	MAIL="/var/qmail/alias/Maildir/"
    fi
else
    if grep -q './Mailbox' /var/service/qmail/defaultdelivery/rc; then
	MAIL="$HOME/Mailbox"
    elif grep -q './Maildir/' /var/service/qmail/defaultdelivery/rc ; then
	MAIL="$HOME/Maildir/"
    fi
fi

# Take care of MH 

MAILDROP="$MAIL" 

export MAIL MAILDROP 
