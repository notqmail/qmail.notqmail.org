#! /bin/sh
set -e

for i in rlc-*.in; do
sed -e "s}CONFRUNLEVELCONF}$RUNLEVELCONF}" \
    -e "s}CONFMYSHELL}$MYSHELL}" \
    $i > $(echo $i| sed 's}\.in$}}') 
done

sed -e "s}CONFRUNLEVEL_LIST}$RUNLEVEL_LIST}" \
    -e "s}CONFMYSHELL}$MYSHELL}" \
    rlc.functions.in > rlc.functions 
    
