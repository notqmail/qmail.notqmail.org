/* PAM exec module
 * (c) 1999 Petr Novotny, ANTEK CS, Petr.Novotny@antek.cz
 *
 * This source is under GPL (GNU public licence)
 *
 *
 * Synopsis:
 *   account  required  pam_exec program_name argv0 [argv1 ...]
 *  or
 *   auth  required  pam_exec program_name argv0 [argv1 ...]
 *  as the last authentication command in the respective class
 *
 * What it does: Returns PAM_SUCCESS (hence it should be the last one) and forks/executes
 *  program program_name
 */


#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <syslog.h>
#include <string.h>
#include <signal.h>
#include <stdarg.h>
#include <errno.h>


#define PROGRAM_NAME "pam_exec"


static void ReportError(int level,const char *message,...)
{
	va_list list;
	va_start(list,message);

	openlog(PROGRAM_NAME,0,LOG_AUTHPRIV);
	vsyslog(level,message,list);
	closelog();

	va_end(list);
}


static void DoTheJob(int argc,const char **argv)
{
	pid_t first_fork,second_fork;
	int status;

	if (argc<=0)
	{
		ReportError(LOG_WARNING,"No arguments for " PROGRAM_NAME);
		return;
	}

	first_fork=fork();
	if (first_fork==-1)
	{
		ReportError(LOG_ERR,"Fork failed: %s",strerror(errno));
	}
	else if (first_fork==0)
	{
		/* I am a child; fork again and spawn the process */
		second_fork=fork();
		if (second_fork==-1)
		{
			ReportError(LOG_ERR,"Fork failed: %s",strerror(errno));
			exit(1);
		}
		else if (second_fork==0)
		{
			/* a child again; setpgrp() and exec() */
			setpgrp();
			execv(argv[0],argc!=1?argv+1:NULL);
			/* if I am here, an error */
			ReportError(LOG_ERR,"Exec failed: %s",strerror(errno));
			exit(1);
		}
		else
		{
			/* a parent */
			signal(SIGCHLD,SIG_IGN);	/* I am not interested in child's death */
			exit(0);
		}
	}
	else
	{
		waitpid(first_fork,&status,0);
	}
}


#define PAM_SM_AUTH
#define PAM_SM_ACCOUNT
#include <security/pam_modules.h>


PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	DoTheJob(argc,argv);
	return PAM_SUCCESS;
}


PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	return PAM_SUCCESS;
}


PAM_EXTERN int pam_sm_acct_mgmt(pam_handle_t *pamh, int flags, int argc, const char **argv)
{
	DoTheJob(argc,argv);
	return PAM_SUCCESS;
}


#ifdef PAM_STATIC
struct pam_module _pam_exec_modstruct = {
	PROGRAM_NAME,
	pam_sm_authenticate,
	pam_sm_setcred,
	pam_sm_acct_mgmt,
	NULL,
	NULL,
	NULL
};
#endif
